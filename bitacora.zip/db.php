<?php
// Configuración de conexión a la base de datos
$serverName = "PALENCIA"; // Cambiar si el servidor tiene un nombre diferente
$connectionInfo = array("Database" => "ProyectoRES", "UID" => "sa", "PWD" => "Pale1234"); // Reemplazar con credenciales reales

$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>
