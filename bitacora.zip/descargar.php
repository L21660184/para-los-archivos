<?php
if (isset($_GET['archivo'])) {
    $archivo = urldecode($_GET['archivo']);
    $archivo_path = 'path/to/files/' . $archivo; // Asegúrate de ajustar esta ruta correctamente

    if (file_exists($archivo_path)) {
        // Cabeceras para la descarga
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($archivo_path) . '"');
        header('Content-Length: ' . filesize($archivo_path));
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        
        readfile($archivo_path); // Lee y envía el archivo
        exit;
    } else {
        echo "El archivo no existe.";
    }
} else {
    echo "No se ha especificado un archivo.";
}
