<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - División de Estudios</title>
    <!-- Estilos -->
    <link rel="stylesheet" href="style.css">
    <!-- Iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Menú lateral -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="https://matehuala.tecnm.mx/SEPRET/Assets/img/favicon.png" alt="Logo" class="logo">
                <h2>SEPRET</h2>
            </div>
            <nav class="sidebar-menu">
                <ul>
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Inicio</a></li>
                    <li><a href="estadisticas.php"><i class="fas fa-chart-bar"></i> Estadísticas de Residencias</a></li>
                    <li><a href="bitacora.php"><i class="fas fa-book"></i> Bitácora de Residencias</a></li>
                    <li><a href="documentos.php"><i class="fas fa-file-alt"></i> Documentos de Residencias</a></li>
                    <li><a href="#"><i class="fas fa-cogs"></i> Configuración</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Contenido principal -->
        <main class="main-content">
            <header class="main-header">
                <h1>División de Estudios</h1>
                <div class="user-info">
                    <span>Hola, <?= htmlspecialchars($_SESSION['usuario']) ?></span>
                    <i class="fas fa-user-circle"></i>
                </div>
            </header>
            
            <section class="cards-section">
                <div class="card">
                    <i class="fas fa-folder-open"></i>
                    <h3>Proyectos Pendientes</h3>
                    <button>Ver detalles</button>
                </div>
                <div class="card">
                    <i class="fas fa-tasks"></i>
                    <h3>Proyectos Vigentes</h3>
                    <button>Ver detalles</button>
                </div>
                <div class="card">
                    <i class="fas fa-check-circle"></i>
                    <h3>Proyectos Finalizados</h3>
                    <button>Ver detalles</button>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
