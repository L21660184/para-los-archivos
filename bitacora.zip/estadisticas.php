<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

include 'db.php';

// Consulta para obtener los proyectos desde la tabla Proyectos2
$query_proyectos = "SELECT id, nombre_proyecto FROM Proyectos2";
$stmt_proyectos = sqlsrv_query($conn, $query_proyectos);

// Si se seleccionó un proyecto, obtener los documentos asociados
$estadisticas = [];
$documentos_subidos = [];
if (isset($_POST['proyecto_id'])) {
    $proyecto_id = $_POST['proyecto_id'];
    
    // Consulta para obtener los documentos del proyecto seleccionado desde Documentos2
    $query_documentos = "SELECT nombre_documento, fecha_carga FROM Documentos2 WHERE proyecto_id = ? ORDER BY fecha_carga";
    $stmt_documentos = sqlsrv_prepare($conn, $query_documentos, array($proyecto_id)); 
    sqlsrv_execute($stmt_documentos);

    while ($row = sqlsrv_fetch_array($stmt_documentos, SQLSRV_FETCH_ASSOC)) {
        $documentos_subidos[] = [
            'nombre_documento' => $row['nombre_documento'],
            'fecha_carga' => $row['fecha_carga']->format('Y-m-d')
        ];
    }
    
    // Consulta para obtener el total de documentos esperados
    $total_requeridos = 4; // Asumiendo que siempre se requieren 4 documentos
    $total_documentos = count($documentos_subidos);
    
    $estadisticas = [
        'total_documentos' => $total_documentos,
        'total_requeridos' => $total_requeridos,
        'porcentaje' => ($total_documentos / $total_requeridos) * 100
    ];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estadísticas de Residencias</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- AOS (Animate On Scroll) -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Menú lateral -->
        <aside class="sidebar">
            <div class="sidebar-header text-center mb-4">
                <img src="https://matehuala.tecnm.mx/SEPRET/Assets/img/favicon.png" alt="Logo" class="logo mb-3">
                <h2>SEPRET</h2>
            </div>
            <nav class="sidebar-menu">
                <ul class="list-unstyled">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Inicio</a></li>
                    <li><a href="estadisticas.php"><i class="fas fa-chart-bar"></i> Estadísticas de Residencias</a></li>
                    <li><a href="bitacora.php"><i class="fas fa-book"></i> Bitácora de Residencias</a></li>
                    <li><a href="documentos.php"><i class="fas fa-file-alt"></i> Documentos de Residencias</a></li>
                    <li><a href="configuracion.php"><i class="fas fa-cogs"></i> Configuración</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Contenido principal -->
        <main class="main-content">
            <header class="main-header text-center mb-4" data-aos="fade-down">
                <h1 class="display-4">Estadísticas de Residencias</h1>
            </header>

            <section class="statistics-section">
                <div class="container">
                    <form method="POST" action="estadisticas.php">
                        <div class="row">
                            <div class="col-12">
                                <label for="proyecto_id" class="form-label">Selecciona un Proyecto</label>
                                <select name="proyecto_id" id="proyecto_id" class="form-select">
                                    <option value="">--Seleccionar Proyecto--</option>
                                    <?php while ($row = sqlsrv_fetch_array($stmt_proyectos, SQLSRV_FETCH_ASSOC)): ?>
                                        <option value="<?= $row['id'] ?>" <?= (isset($proyecto_id) && $proyecto_id == $row['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($row['nombre_proyecto']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3">Ver Estadísticas</button>
                    </form>

                    <?php if (!empty($estadisticas)): ?>
                        <div class="row mt-5">
                            <div class="col-12 col-md-6">
                                <h3>Historial de Documentos Cargados</h3>
                                <ul class="list-group">
                                    <?php foreach ($documentos_subidos as $doc): ?>
                                        <li class="list-group-item">
                                            <strong><?= htmlspecialchars($doc['nombre_documento']) ?></strong> - <?= $doc['fecha_carga'] ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <div class="col-12 col-md-6">
                                <h3>Gráfico de Progreso</h3>
                                <canvas id="myChart"></canvas>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AOS JS -->
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init();

        <?php if (!empty($estadisticas)): ?>
            var ctx = document.getElementById('myChart').getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?= json_encode(array_column($documentos_subidos, 'fecha_carga')) ?>,
                    datasets: [{
                        label: 'Documentos Cargados',
                        data: <?= json_encode(array_fill(0, count($documentos_subidos), 1)) ?>,
                        backgroundColor: 'rgba(0, 123, 255, 0.2)',
                        borderColor: 'rgba(0, 123, 255, 1)',
                        borderWidth: 2,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return 'Documentos cargados: ' + tooltipItem.raw;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            type: 'category',
                            title: {
                                display: true,
                                text: 'Fechas'
                            }
                        },
                        y: {
                            title: {
                                display: true,
                                text: 'Cantidad de Documentos'
                            },
                            beginAtZero: true
                        }
                    }
                }
            });
        <?php endif; ?>
    </script>
</body>
</html>

