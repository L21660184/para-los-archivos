<?php
// Archivo para conexión con la base de datos
include 'db.php';

// Iniciar sesión en PHP
session_start();

// Verificar si se envió el formulario de inicio de sesión
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Consulta para validar las credenciales
    $query = "SELECT * FROM Usuarios WHERE usuario = ? AND password = ?";
    $params = array($usuario, $password);
    $stmt = sqlsrv_prepare($conn, $query, $params);

    if (sqlsrv_execute($stmt) && sqlsrv_fetch($stmt)) {
        // Guardar el usuario en la sesión
        $_SESSION['usuario'] = $usuario;

        // Redirigir al dashboard
        header("Location: dashboard.php");
        exit;
    } else {
        // Mensaje de error si las credenciales no son válidas
        $error = "Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <!-- Logo principal -->
        <img src="https://matehuala.tecnm.mx/SEPRET/Assets/img/favicon.png" alt="Logo TecNM" class="logo">
        <h1>Iniciar Sesión</h1>

        <!-- Formulario de inicio de sesión -->
        <form method="POST" action="">
            <input type="text" name="usuario" placeholder="Usuario" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Entrar</button>
        </form>

        <!-- Mostrar error si existe -->
        <?php if (isset($error)): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
