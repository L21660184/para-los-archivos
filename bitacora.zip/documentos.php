<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

include 'db.php';

// Consulta para obtener todos los proyectos desde la tabla Proyectos2
$query_proyectos = "SELECT id, nombre_proyecto FROM Proyectos2";
$stmt_proyectos = sqlsrv_query($conn, $query_proyectos);

// Si se seleccionó un proyecto, obtener los documentos asociados
$documentos = [];
if (isset($_POST['proyecto_id'])) {
    $proyecto_id = $_POST['proyecto_id'];
    
    // Consulta para obtener los documentos del proyecto seleccionado desde Documentos2
    $query_documentos = "SELECT * FROM Documentos2 WHERE proyecto_id = ?";
    $stmt_documentos = sqlsrv_prepare($conn, $query_documentos, array($proyecto_id)); 
    sqlsrv_execute($stmt_documentos);
    
    // Guardar los resultados en un array
    while ($row = sqlsrv_fetch_array($stmt_documentos, SQLSRV_FETCH_ASSOC)) {
        $documentos[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentos de Residencias</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- AOS (Animate On Scroll) -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="style.css">
    <style>
        /* Menú lateral */
        .sidebar {
            position: fixed;
            top: 0;
            left: -250px;
            height: 100%;
            width: 250px;
            background-color: #007bff;
            color: white;
            padding-top: 30px;
            transition: 0.3s;
            z-index: 100;
        }

        .sidebar-header img {
            width: 50%;
        }

        .sidebar-menu ul {
            padding: 0;
        }

        .sidebar-menu ul li {
            list-style: none;
            padding: 15px;
            text-align: left;
        }

        .sidebar-menu ul li a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .sidebar-menu ul li a:hover {
            background-color: #0056b3;
        }

        /* Botón para abrir/cerrar el menú */
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 110;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            padding: 15px;
            cursor: pointer;
            font-size: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .sidebar-toggle:hover {
            background-color: #0056b3;
        }

        /* Contenido principal */
        .main-content {
            margin-left: 250px;
            padding: 30px;
            transition: margin-left 0.3s;
        }

        .main-header {
            background-color: #007bff;
            color: white;
            padding: 20px 0;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .documents-section {
            margin-top: 20px;
        }

        /* Tabla de documentos */
        .table-responsive {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            background-color: #fff;
        }

        table.table th, table.table td {
            vertical-align: middle;
            padding: 15px;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: #f1f1f1;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        /* Estilos de botones */
        .btn-custom {
            background-color: #007bff;
            color: white;
            border-radius: 50px;
            padding: 10px 20px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        /* Estilo de formulario */
        .form-select, .form-label {
            font-size: 16px;
        }

        .form-control {
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 16px;
        }

        /* Responsividad */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px; /* Se oculta por defecto */
            }

            .main-content {
                margin-left: 0;
            }

            .sidebar-toggle {
                display: block;
            }

            .table td, .table th {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Botón para abrir/cerrar el menú lateral -->
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Menú lateral -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header text-center mb-4">
                <img src="https://matehuala.tecnm.mx/SEPRET/Assets/img/favicon.png" alt="Logo" class="logo mb-3">
                <h2>SEPRET</h2>
            </div>
            <nav class="sidebar-menu">
                <ul class="list-unstyled">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Inicio</a></li>
                    <li><a href="estadisticas.php"><i class="fas fa-chart-bar"></i> Estadísticas de Residencias</a></li>
                    <li><a href="bitacora.php"><i class="fas fa-book"></i> Bitácora de Residencias</a></li>
                    <li><a href="documentos.php"><i class="fas fa-file-alt"></i> Documentos de Residencias</a></li>
                    <li><a href="configuracion.php"><i class="fas fa-cogs"></i> Configuración</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Contenido principal -->
        <main class="main-content">
            <header class="main-header text-center mb-4" data-aos="fade-down">
                <h1 class="display-4">Documentos de Residencias</h1>
            </header>

            <section class="documents-section">
                <div class="container">
                    <form method="POST" action="documentos.php" class="mb-5">
                        <div class="row">
                            <div class="col-12">
                                <label for="proyecto_id" class="form-label">Selecciona un Proyecto</label>
                                <select name="proyecto_id" id="proyecto_id" class="form-select">
                                    <option value="">--Seleccionar Proyecto--</option>
                                    <?php while ($row = sqlsrv_fetch_array($stmt_proyectos, SQLSRV_FETCH_ASSOC)): ?>
                                        <option value="<?= $row['id'] ?>" <?= (isset($proyecto_id) && $proyecto_id == $row['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($row['nombre_proyecto']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-custom mt-3">Buscar</button>
                    </form>

                    <?php if (!empty($documentos)): ?>
                        <div class="row mt-5">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Nombre del Documento</th>
                                                <th>Fecha de Carga</th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($documentos as $documento): ?>
                                                <tr data-aos="fade-up">
                                                    <td><?= htmlspecialchars($documento['nombre_documento']) ?></td>
                                                    <td><?= htmlspecialchars($documento['fecha_carga']->format('Y-m-d H:i:s')) ?></td>
                                                    <td>
                                                        <a href="descargar_documento.php?id=<?= $documento['id'] ?>" class="btn btn-custom btn-sm">
                                                            <i class="fas fa-download"></i> Descargar
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>

    <script>
        // Función para abrir y cerrar el menú lateral
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const currentLeft = sidebar.style.left;
            if (currentLeft === '0px') {
                sidebar.style.left = '-250px';
            } else {
                sidebar.style.left = '0';
            }
        }
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AOS (Animate On Scroll) JS -->
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>

