<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Proyecto</title>
</head>
<body>
    <h2>Formulario de Proyecto</h2>
    <form action="submit_project.php" method="POST" enctype="multipart/form-data">
        <label for="nombre">Nombre del Proyecto:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>

        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion" required></textarea><br><br>

        <label for="fecha_inicio">Fecha de Inicio:</label>
        <input type="date" id="fecha_inicio" name="fecha_inicio" required><br><br>

        <label for="fecha_fin">Fecha de Fin:</label>
        <input type="date" id="fecha_fin" name="fecha_fin" required><br><br>

        <label for="file">Adjuntar Archivo:</label>
        <input type="file" id="file" name="file" required><br><br>

        <button type="submit">Subir Proyecto</button>
    </form>
</body>
</html>
